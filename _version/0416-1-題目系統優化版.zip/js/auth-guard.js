/**
 * 幼獅題庫系統 — 頁面守衛 + 側欄渲染
 * =====================================================
 * 每個需要登入的頁面在 <script type="module"> 頂端引入：
 *   import { guardPage } from './js/auth-guard.js';
 *   await guardPage();                          // 只需登入
 *   await guardPage(['admin']);                 // 限管理員
 *   await guardPage(['admin','teacher']);       // 教師或管理員
 *
 * 此模組會自動：
 *   1. 等候 Firebase auth 初始化
 *   2. 未登入則跳轉 index.html
 *   3. 角色不符則跳轉 dashboard.html
 *   4. 渲染側邊欄
 *   5. 將 .main 加上 .ready class 觸發淡入
 * =====================================================
 */
import './firebase.js';

export async function guardPage(allowedRoles) {
  await window._dsReady;
  const user = DataService.getCurrentUser();
  if (!user) { window.location.href = 'index.html'; return null; }
  if (allowedRoles && !allowedRoles.includes(user.role)) {
    window.location.href = 'dashboard.html'; return null;
  }
  // 渲染側邊欄
  const el = document.getElementById('sidebar');
  if (el) renderSidebar(el, window._activeNav || '');
  // 觸發主內容淡入
  requestAnimationFrame(() => {
    document.querySelector('.main')?.classList.add('ready');
  });
  return user;
}

export function renderSidebar(el, active) {
  const user = DataService.getCurrentUser();
  if (!user) return;
  const I = window.ICONS || {};
  const ROLES = {
    admin:   { label:'管理員', icon: I.tool || '🛡️' },
    teacher: { label:'教師',   icon: I.award || '🎓' },
    student: { label:'學生',   icon: I.user || '🧑‍🎓' }
  };
  const ri  = ROLES[user.role] || ROLES.student;
  const ini = (user.displayName || user.email || '?')[0].toUpperCase();

  const nav = (page, icon, label) =>
    `<div class="nav-item ${active===page?'active':''}" onclick="nav('${page}')">
       <span class="icon">${icon}</span>${label}
     </div>`;

  const adminNav = `
    <div class="nav-section-title">題庫管理</div>
    ${nav('textbooks', I.book20    || '📚', '課本管理')}
    ${nav('import',    I.upload20  || '📥', '題目匯入')}
    ${nav('questions', I.list20    || '📋', '題目維護')}`;

  const staffNav = `
    <div class="nav-section-title">出題管理</div>
    ${nav('compose', I.auto20      || '✏️', '電腦選題')}
    ${nav('manual',  I.edit20      || '✦',  '手動選題')}
    ${nav('coded',   I.code20      || '🔢', '編碼選題')}
    ${nav('exams',   I.folder20    || '📁', '試卷管理')}
    <div class="nav-section-title">班級管理</div>
    ${nav('classes', I.school20    || '🏫', '班級管理')}
    <div class="nav-section-title">成績管理</div>
    ${nav('results', I.chart20     || '📊', '成績查詢')}
    <div class="nav-section-title">系統設定</div>
    ${nav('settings',I.settings20  || '⚙️', '帳號與設定')}`;

  const studentNav = `
    <div class="nav-section-title">線上考試</div>
    ${nav('take',       I.test20    || '📝', '參加考試')}
    ${nav('my-results', I.chart20   || '📊', '我的成績')}
    <div class="nav-section-title">班級</div>
    ${nav('classes',    I.school20  || '🏫', '我的班級')}
    <div class="nav-section-title">設定</div>
    ${nav('settings',   I.settings20|| '⚙️', '帳號設定')}`;

  const navMap = {
    admin:   adminNav + staffNav,
    teacher: staffNav,
    student: studentNav
  };

  el.innerHTML = `
    <div class="sidebar-logo">
      <h1>幼獅題庫系統</h1>
      <span>線上版 v2.1</span>
    </div>
    <div class="sidebar-user">
      <div class="avatar">${ini}</div>
      <div class="user-info">
        <div class="user-name">${user.displayName || user.email}</div>
        <div class="user-role"><span class="role-icon">${ri.icon}</span> ${ri.label}</div>
      </div>
    </div>
    <nav class="sidebar-nav">
      ${nav('dashboard', I.home20 || '🏠', '首頁總覽')}
      ${navMap[user.role] || studentNav}
    </nav>
    <div class="sidebar-footer">
      <button class="logout-btn" id="logoutBtn">${I.logout18 || '⬅'} 登出</button>
    </div>`;

  document.getElementById('logoutBtn').onclick = () => DataService.logout();
}
