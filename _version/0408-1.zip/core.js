/**
 * 幼獅題庫系統 — 核心資料模組
 * 負責：資料庫存取、帳號驗證、共用工具函式
 */

// ════════════════════════════════════════
//  常數與代碼對照表
// ════════════════════════════════════════
const QUESTION_TYPES = {
  T1: '是非題', T2: '單選題', T3: '複選題',
  T4: '填空題', T5: '配合題', T6: '問答題'
};
const DIFFICULTY = {
  '△': '簡易', '◎': '較難', '': '一般'
};
const SOURCE_CODES = {
  A1: '課本', A2: '四技二專考題'
};

// 科目代碼對照
const SUBJECT_CODES = {
  A1: '大學全民國防教育',
  B1: '高中全民國防教育',
  C1: '健康與護理',
  D1: '生涯規劃',
  E1: '家政',
  F1: '生命教育',
  G1: '高中美術',
  H1: '技高美術',
  I1: '生活科技'
};

// 冊別對照（每科不同）
const BOOK_CODES = {
  A1: { '01':'國際情勢','02':'國防政策','03':'全民國防','04':'防衛動員','05':'國防科技' },
  B1: { '01':'高中全民國防教育（甲版）','02':'高中全民國防教育（乙版）' },
  C1: { '01':'健康與護理','02':'安全教育與傷害防護','03':'運動與健康','04':'健康與休閒生活' },
  D1: { '01':'高中生涯規劃','02':'選修','03':'技高生涯規劃' },
  E1: { '01':'高中家政','02':'選修' },
  F1: { '01':'生命教育','02':'選修' },
  G1: { '01':'高中美術（上）','02':'高中美術（下）','03':'高中藝術生活','04':'選修' },
  H1: { '01':'技高美術' },
  I1: { '01':'生活科技' }
};

// ════════════════════════════════════════
//  Storage 封裝（localStorage）
// ════════════════════════════════════════
const DB = {
  _key: k => `qbank_${k}`,

  get(key) {
    try { return JSON.parse(localStorage.getItem(DB._key(key))); }
    catch { return null; }
  },
  set(key, val) {
    localStorage.setItem(DB._key(key), JSON.stringify(val));
  },
  remove(key) { localStorage.removeItem(DB._key(key)); },

  // 題目 CRUD
  getQuestions() { return DB.get('questions') || []; },
  setQuestions(qs) { DB.set('questions', qs); },
  addQuestions(newQs) {
    const qs = DB.getQuestions();
    const maxId = qs.reduce((m, q) => Math.max(m, q.id || 0), 0);
    newQs.forEach((q, i) => { q.id = maxId + i + 1; });
    DB.set('questions', [...qs, ...newQs]);
    return newQs.length;
  },
  updateQuestion(id, data) {
    const qs = DB.getQuestions();
    const idx = qs.findIndex(q => q.id === id);
    if (idx >= 0) { qs[idx] = { ...qs[idx], ...data }; DB.setQuestions(qs); return true; }
    return false;
  },
  deleteQuestion(id) {
    const qs = DB.getQuestions().filter(q => q.id !== id);
    DB.setQuestions(qs);
  },

  // 試卷管理
  getExams() { return DB.get('exams') || []; },
  saveExam(exam) {
    const exams = DB.getExams();
    if (!exam.id) {
      exam.id = Date.now();
      exam.createdAt = new Date().toISOString();
      exams.push(exam);
    } else {
      const idx = exams.findIndex(e => e.id === exam.id);
      if (idx >= 0) exams[idx] = exam;
    }
    DB.set('exams', exams);
    return exam.id;
  },
  deleteExam(id) { DB.set('exams', DB.getExams().filter(e => e.id !== id)); },

  // 成績記錄
  getResults() { return DB.get('results') || []; },
  saveResult(result) {
    const results = DB.getResults();
    result.id = Date.now();
    result.submittedAt = new Date().toISOString();
    results.push(result);
    DB.set('results', results);
    return result.id;
  },

  // 帳號管理
  getUsers() { return DB.get('users') || []; },
  setUsers(users) { DB.set('users', users); },

  // 科目/章節目錄
  getCatalog() { return DB.get('catalog') || []; },
  setCatalog(data) { DB.set('catalog', data); },
};

// ════════════════════════════════════════
//  帳號驗證
// ════════════════════════════════════════
const Auth = {
  ADMIN_CODE: 'teacher2024',   // 老師管理碼（可由老師自行修改）

  getCurrentUser() {
    return DB.get('currentUser');
  },
  isLoggedIn() {
    return !!Auth.getCurrentUser();
  },
  isTeacher() {
    const u = Auth.getCurrentUser();
    return u && u.role === 'teacher';
  },
  isStudent() {
    const u = Auth.getCurrentUser();
    return u && u.role === 'student';
  },

  login(username, password, role) {
    const users = DB.getUsers();
    const user = users.find(u => u.username === username);
    if (!user) return { ok: false, msg: '帳號不存在' };
    if (user.password !== password) return { ok: false, msg: '密碼錯誤' };
    if (user.role !== role) return { ok: false, msg: `此帳號為${user.role === 'teacher' ? '教師' : '學生'}帳號` };
    DB.set('currentUser', user);
    return { ok: true, user };
  },

  register(data) {
    const users = DB.getUsers();
    if (users.find(u => u.username === data.username)) {
      return { ok: false, msg: '帳號已存在' };
    }
    const user = {
      id: Date.now(),
      username: data.username,
      password: data.password,
      displayName: data.displayName || data.username,
      role: data.role,
      createdAt: new Date().toISOString()
    };
    users.push(user);
    DB.setUsers(users);
    return { ok: true, user };
  },

  logout() {
    DB.remove('currentUser');
    window.location.href = 'index.html';
  },

  requireLogin(role) {
    if (!Auth.isLoggedIn()) {
      window.location.href = 'index.html';
      return false;
    }
    if (role === 'teacher' && !Auth.isTeacher()) {
      window.location.href = 'index.html';
      return false;
    }
    return true;
  },

  getAdminCode() { return DB.get('adminCode') || Auth.ADMIN_CODE; },
  setAdminCode(code) { DB.set('adminCode', code); },
  verifyAdminCode(code) { return code === Auth.getAdminCode(); }
};

// ════════════════════════════════════════
//  題目查詢與篩選
// ════════════════════════════════════════
const QuestionQuery = {
  filter(opts = {}) {
    let qs = DB.getQuestions();
    if (opts.subjectCode)   qs = qs.filter(q => q.subjectCode === opts.subjectCode);
    if (opts.bookCode)      qs = qs.filter(q => q.bookCode === opts.bookCode);
    if (opts.type)          qs = qs.filter(q => q.type === opts.type);
    if (opts.difficulty)    qs = qs.filter(q => q.difficulty === opts.difficulty);
    if (opts.chapterNum)    qs = qs.filter(q => q.chapterNum === opts.chapterNum);
    if (opts.sectionNum)    qs = qs.filter(q => q.sectionNum === opts.sectionNum);
    if (opts.subsectionNum) qs = qs.filter(q => q.subsectionNum === opts.subsectionNum);
    if (opts.keyword) {
      const kw = opts.keyword.toLowerCase();
      qs = qs.filter(q =>
        (q.text || '').includes(kw) ||
        (q.answer || '').includes(kw) ||
        (q.analysis || '').includes(kw)
      );
    }
    return qs;
  },

  // 依節點代碼篩選（目錄代碼，如 B1-01-010101）
  filterByCatalogCode(rangeCode) {
    return DB.getQuestions().filter(q => q.catalogCode === rangeCode);
  },

  // 取得統計
  getStats() {
    const qs = DB.getQuestions();
    const stats = { total: qs.length, byType: {}, bySubject: {}, byDifficulty: {} };
    qs.forEach(q => {
      stats.byType[q.type] = (stats.byType[q.type] || 0) + 1;
      stats.bySubject[q.subjectCode] = (stats.bySubject[q.subjectCode] || 0) + 1;
      stats.byDifficulty[q.difficulty || ''] = (stats.byDifficulty[q.difficulty || ''] || 0) + 1;
    });
    return stats;
  },

  // 亂數取題
  random(opts = {}, count = 10) {
    let pool = QuestionQuery.filter(opts);
    if (opts.catalogCodes && opts.catalogCodes.length) {
      pool = pool.filter(q => opts.catalogCodes.includes(q.catalogCode));
    }
    const shuffled = [...pool].sort(() => Math.random() - 0.5);
    return shuffled.slice(0, count);
  }
};

// ════════════════════════════════════════
//  Word 入題檔解析器
// ════════════════════════════════════════
const DocImporter = {
  // 解析 Markdown 表格（pandoc 轉出格式）
  parseMarkdownTable(text) {
    const lines = text.split('\n').map(l => l.trim()).filter(l => l.startsWith('|'));
    if (lines.length < 3) return [];
    // 第一列：標題
    const headers = lines[0].split('|').map(h => h.trim()).filter(Boolean);
    const rows = [];
    for (let i = 2; i < lines.length; i++) {
      const cells = lines[i].split('|').map(c => c.trim()).filter((c, idx, arr) => idx < arr.length - 1 || c !== '');
      // 移除首尾空的 pipe
      const cleanCells = lines[i].split('|').slice(1, -1).map(c => c.trim());
      if (cleanCells.length === 0) continue;
      const row = {};
      headers.forEach((h, idx) => { row[h] = cleanCells[idx] || ''; });
      rows.push(row);
    }
    return rows;
  },

  // 將一列資料轉成題目物件
  rowToQuestion(row, subjectCode, bookCode) {
    const type = (row['題型'] || '').trim();
    const isChoice = type === 'T2';

    // 組合目錄代碼
    const chap = (row['章數'] || '').padStart(2,'0');
    const sec  = (row['節數'] || '').padStart(2,'0');
    const sub  = (row['小節'] || '').padStart(2,'0');
    let catalogCode = '';
    if (subjectCode && bookCode) {
      if (subjectCode === 'B1') {
        // B1 格式：B1-01-010101（單元+章+節各2位）
        catalogCode = `${subjectCode}-${bookCode}-${chap}${sec}${sub}`;
      } else if (subjectCode === 'C1') {
        catalogCode = `${subjectCode}-${bookCode}-${chap}${sec}`;
      } else {
        catalogCode = `${subjectCode}-${bookCode}-${chap}`;
      }
    }

    const q = {
      subjectCode,
      bookCode,
      type,
      difficulty: (row['難易'] || '').trim(),
      source: (row['頁數/出處'] || row['頁數'] || '').trim(),
      sourceCode: (row['來源'] || 'A1').trim(),
      answerCount: parseInt(row['答數'] || '1') || 1,
      answer: (row['簡答/答案'] || row['簡答'] || '').trim(),
      text: (row['題目'] || '').trim(),
      analysis: (row['詳答/解析'] || row['詳答'] || '').trim(),
      chapterNum: chap,
      sectionNum: sec,
      subsectionNum: sub,
      catalogCode,
    };

    // 單選題特有欄位
    if (isChoice) {
      q.options = [
        row['選項1'] || '', row['選項2'] || '',
        row['選項3'] || '', row['選項4'] || '',
        row['選項5'] || ''
      ].filter(o => o !== '');
      q.tail = (row['結尾'] || '').trim();
    }

    return q;
  },

  // 從文字內容解析（支援 Markdown 表格格式）
  parseText(text, subjectCode, bookCode) {
    const rows = DocImporter.parseMarkdownTable(text);
    if (!rows.length) return [];
    return rows
      .filter(r => r['題型'] && r['題目'])
      .map(r => DocImporter.rowToQuestion(r, subjectCode, bookCode));
  }
};

// ════════════════════════════════════════
//  共用 UI 工具
// ════════════════════════════════════════
const UI = {
  // 渲染側邊欄
  renderSidebar(containerId, activeItem) {
    const user = Auth.getCurrentUser();
    if (!user) return;
    const isTeacher = user.role === 'teacher';
    const initial = (user.displayName || user.username || '?')[0].toUpperCase();

    const teacherNav = `
      <div class="nav-section-title">題庫管理</div>
      <div class="nav-item ${activeItem==='import'?'active':''}" onclick="nav('import')">
        <span class="icon">📥</span>題目匯入
      </div>
      <div class="nav-item ${activeItem==='questions'?'active':''}" onclick="nav('questions')">
        <span class="icon">📋</span>題目維護
      </div>
      <div class="nav-section-title">出題管理</div>
      <div class="nav-item ${activeItem==='compose'?'active':''}" onclick="nav('compose')">
        <span class="icon">✏️</span>電腦出題
      </div>
      <div class="nav-item ${activeItem==='manual'?'active':''}" onclick="nav('manual')">
        <span class="icon">🖊️</span>人工選題
      </div>
      <div class="nav-item ${activeItem==='exams'?'active':''}" onclick="nav('exams')">
        <span class="icon">📁</span>試卷管理
      </div>
      <div class="nav-section-title">成績管理</div>
      <div class="nav-item ${activeItem==='results'?'active':''}" onclick="nav('results')">
        <span class="icon">📊</span>成績查詢
      </div>
      <div class="nav-section-title">系統設定</div>
      <div class="nav-item ${activeItem==='settings'?'active':''}" onclick="nav('settings')">
        <span class="icon">⚙️</span>帳號與設定
      </div>`;

    const studentNav = `
      <div class="nav-section-title">線上考試</div>
      <div class="nav-item ${activeItem==='take'?'active':''}" onclick="nav('take')">
        <span class="icon">📝</span>參加考試
      </div>
      <div class="nav-item ${activeItem==='my-results'?'active':''}" onclick="nav('my-results')">
        <span class="icon">📊</span>我的成績
      </div>`;

    document.getElementById(containerId).innerHTML = `
      <div class="sidebar-logo">
        <h1>幼獅題庫系統</h1>
        <span>線上版 v1.0</span>
      </div>
      <div class="sidebar-user">
        <div class="avatar">${initial}</div>
        <div class="user-info">
          <div class="user-name">${user.displayName || user.username}</div>
          <div class="user-role">${isTeacher ? '🎓 教師' : '🧑‍🎓 學生'}</div>
        </div>
      </div>
      <nav class="sidebar-nav">
        <div class="nav-item ${activeItem==='dashboard'?'active':''}" onclick="nav('dashboard')">
          <span class="icon">🏠</span>首頁總覽
        </div>
        ${isTeacher ? teacherNav : studentNav}
      </nav>
      <div class="sidebar-footer">
        <button class="logout-btn" onclick="Auth.logout()">
          <span>⬅</span> 登出
        </button>
      </div>`;
  },

  // toast 通知
  toast(msg, type = 'info', duration = 3000) {
    const colors = { success:'#1e8449', danger:'#c0392b', warning:'#d35400', info:'#1a3a5c' };
    const icons  = { success:'✓', danger:'✕', warning:'⚠', info:'ℹ' };
    const t = document.createElement('div');
    t.style.cssText = `
      position:fixed;bottom:24px;right:24px;z-index:9999;
      background:${colors[type]||colors.info};color:white;
      padding:12px 18px;border-radius:8px;
      box-shadow:0 4px 16px rgba(0,0,0,.2);
      font-size:.875rem;display:flex;align-items:center;gap:8px;
      animation:slideUp .2s ease;max-width:320px;
    `;
    t.innerHTML = `<strong>${icons[type]||'ℹ'}</strong>${msg}`;
    document.body.appendChild(t);
    setTimeout(() => { t.style.opacity='0'; t.style.transition='opacity .3s'; setTimeout(()=>t.remove(),300); }, duration);
  },

  // 確認對話框
  confirm(msg) { return window.confirm(msg); },

  // 格式化日期
  formatDate(iso) {
    if (!iso) return '-';
    const d = new Date(iso);
    return `${d.getFullYear()}/${String(d.getMonth()+1).padStart(2,'0')}/${String(d.getDate()).padStart(2,'0')}`;
  },
  formatDateTime(iso) {
    if (!iso) return '-';
    const d = new Date(iso);
    return `${UI.formatDate(iso)} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
  },

  // 題型 badge HTML
  typeBadge(type) {
    return `<span class="badge badge-${type.toLowerCase()}">${QUESTION_TYPES[type]||type}</span>`;
  },
  diffBadge(diff) {
    if (diff === '◎') return `<span class="badge badge-hard">較難</span>`;
    if (diff === '△') return `<span class="badge badge-easy">簡易</span>`;
    return `<span class="badge badge-normal">一般</span>`;
  },

  // 建立選單選項
  buildOptions(obj, selected = '', placeholder = '請選擇') {
    let html = placeholder ? `<option value="">${placeholder}</option>` : '';
    Object.entries(obj).forEach(([val, label]) => {
      html += `<option value="${val}" ${selected===val?'selected':''}>${label}</option>`;
    });
    return html;
  }
};

// ════════════════════════════════════════
//  初始化：建立預設帳號
// ════════════════════════════════════════
function initDefaultAccounts() {
  if (DB.getUsers().length > 0) return;
  DB.setUsers([
    { id: 1, username: 'teacher', password: 'teacher123', displayName: '系統老師', role: 'teacher', createdAt: new Date().toISOString() },
    { id: 2, username: 'student', password: 'student123', displayName: '示範學生', role: 'student', createdAt: new Date().toISOString() }
  ]);
}
initDefaultAccounts();

// 頁面導航
function nav(page) {
  const pages = {
    dashboard: 'dashboard.html',
    import:    'import.html',
    questions: 'questions.html',
    compose:   'compose.html',
    manual:    'manual.html',
    exams:     'exams.html',
    results:   'results.html',
    settings:  'settings.html',
    take:      'take.html',
    'my-results': 'my-results.html'
  };
  if (pages[page]) window.location.href = pages[page];
}
